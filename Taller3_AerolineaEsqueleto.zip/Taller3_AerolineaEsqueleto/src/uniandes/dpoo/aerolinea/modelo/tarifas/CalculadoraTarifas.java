package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	public double IMPUESTO = 0.28; 
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		int base = calcularCostoBase(vuelo, cliente);
		double descuento = calcularPorcentajeDescuento(cliente);
		int costo1 = (int) ((int) base*(1-descuento));
		int impuesto = calcularValorImpuestos(costo1);
		int costo2 = costo1 + impuesto;
		return costo2; 
				
	}
	protected int calcularValorImpuestos(int costoBase) {
        return (int) (costoBase * IMPUESTO);
    }
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	protected int calcularDistanciaVuelo(Ruta ruta) {
		 Aeropuerto origen = ruta.getOrigen();
	     Aeropuerto destino = ruta.getDestino();
	        
	     double lat1 = Math.toRadians(origen.getLatitud());
	     double lon1 = Math.toRadians(origen.getLongitud());
	     double lat2 = Math.toRadians(destino.getLatitud());
	     double lon2 = Math.toRadians(destino.getLongitud());
	        
	     double dlat = lat2 - lat1;
	     double dlon = lon2 - lon1;
	        
	     double a = Math.sin(dlat / 2) * Math.sin(dlat / 2) +
	                   Math.cos(lat1) * Math.cos(lat2) *
	                   Math.sin(dlon / 2) * Math.sin(dlon / 2);
	        
	     double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
	     return (int) (6371* c);
    }
	
}
