package uniandes.dpoo.aerolinea.modelo.cliente;
import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

import java.util.Collection;
import java.util.Iterator;

public abstract class Cliente {
	protected List<Tiquete> tiquetes;
	
	public Cliente() {
		this.tiquetes = new ArrayList<>();
	}
	public abstract String getTipoCliente();
	public abstract String getIdentificador();
	public void agregarTiquete(Tiquete tiquete) {
		this.tiquetes.add(tiquete);
	}
	public int CalcularValorTotalTiquetes() {
		int total = 0; 
		Iterator<Tiquete> it = this.tiquetes.iterator();
		while (it.hasNext()) {
			Tiquete tiquete = it.next();
			total += tiquete.getTarifa();
		}
		return total;
	}
	public void usarTiquetes(Vuelo vuelo) {
		Collection<Tiquete> todos = vuelo.getTiquetes(); 
		for (Tiquete tiquete: todos) {
			tiquete.marcarComoUsado();
			this.tiquetes.remove(tiquete);
		}
	}
}
