package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



import uniandes.dpoo.hamburguesas.mundo.Ingrediente; 
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;

public class ProductoAjustadoTest {
	 	private Ingrediente i1;
	    private Ingrediente i2;
	    private ProductoMenu pBase;
	    private ProductoAjustado pAjustado;

	 @BeforeEach
	    void setUp( ) throws Exception
	    {
		 	i1 = new Ingrediente("Lechuga",50);
		 	i2 = new Ingrediente("Carne XL", 280);
		 	pBase = new ProductoMenu("Hamburguesa Doble", 980);
		 	pAjustado = new ProductoAjustado(pBase);
		 	pAjustado.agregarIngrediente(i1); 
		 	pAjustado.eliminarIngrediente(i2);
	    }
	 @AfterEach
	    void tearDown( ) throws Exception
	    {
	    }
	 @Test
	    void testGetNombre( )
	    {
	        assertEquals( "Hamburguesa Doble", pAjustado.getNombre( ), "El nombre del producto no es el esperado." );
	    }
	 @Test
	 	void testGetPrecio()
	 	{
		 	assertEquals(1030, pAjustado.getPrecio(), "El precio no es correcto");
	 	}
	 @Test
	    void testGenerarTextoFactura() {
		 String esperado = 
			        "Hamburguesa Doble" +
			        "    +Lechuga                50" +
			        "    -Carne XL" +
			        "            1030\n";

			    String generado = pAjustado.generarTextoFactura();

			    assertEquals(esperado, generado, "El texto de la factura no está en el formato correcto");
			}
}
	


