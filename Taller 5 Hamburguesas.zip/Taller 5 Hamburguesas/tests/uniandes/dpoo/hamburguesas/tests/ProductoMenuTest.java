package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.*;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
public class ProductoMenuTest {
	
	
	private ProductoMenu productoM1;
	private ProductoMenu productoM2;
	@BeforeEach
	void setUp( ) throws ProductoRepetidoException 
	    {
	        productoM1 = new ProductoMenu("Pollo", 1500 );
	        productoM2 = new ProductoMenu("Pollo", 1500);
	    }
	@AfterEach 
	void tearDown( ) throws ProductoRepetidoException
    {
    }
    @Test
    void testGetNombre()
    {
        assertEquals( "Pollo", productoM1.getNombre( ), "El nombre del producto no es el esperado." );
        assertEquals( "Pollo", productoM2.getNombre( ), "El nombre del producto no es el esperado." );
    }
    
    @Test
    void testGetPrecio()
    {
    	assertEquals(1500, productoM1.getPrecio(), "El precio no es el esperado");
    	assertEquals(1500, productoM2.getPrecio(), "El precio no es el esperado");
    }
    @Test
    void testGenerarTextoFactura()
    {
    	assertEquals("Pollo\n            1500\n", productoM1.generarTextoFactura(), "El texto de la factura no está en el formato correcto");
    	assertEquals("Pollo\n            1500\n", productoM2.generarTextoFactura(), "El texto de la factura no está en el formato correcto");
    }
    @Test
    void testProductoRepetidoExceptionMessage() {
        ProductoRepetidoException rep = new ProductoRepetidoException("Pollo");
        assertEquals("El producto Pollo está repetido", rep.getMessage());
    }
	
}
