package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.excepciones.*;

public class PedidoTest {
	private ProductoMenu p1; 
	private ProductoMenu p2;
	private ProductoMenu p3;
	private Pedido Pedido1;

	@BeforeEach
	void setUp( ) throws Exception
		{
			Pedido1 = new Pedido("Camila", "Calle del Toro");
			p1 = new ProductoMenu("QueenBurger", 1200);
			p2 = new ProductoMenu("Sprite", 110);
			p3 = new ProductoMenu("Cookies&Cream", 220);
			Pedido1.agregarProducto(p1);
			Pedido1.agregarProducto(p2);
			Pedido1.agregarProducto(p3);
		
		}
    @AfterEach
    void tearDown( ) throws Exception
    {

    }
    @Test
    void testIdPedido() 
    {
        assertEquals(7, Pedido1.getIdPedido());
    }
    @Test
    void testGetNombreCliente()
    {
    	assertEquals("Camila", Pedido1.getNombreCliente());
    }
    @Test
    void testGetPrecioTotal()
    {
    	assertEquals(1820, Pedido1.getPrecioTotalPedido(), "El precio total no está bien calculado");
    }
    @Test
    void testGenerarTextoFactura()
    {
    	assertEquals("Cliente: Camila\n" +
    		    "Dirección: Calle del Toro\n" +
    		    "----------------\n" +
    		    "QueenBurger\n" +
    		    "            1200\n" +
    		    "Sprite\n" +
    		    "            110\n" +
    		    "Cookies&Cream\n" +
    		    "            220\n" +
    		    "----------------\n" +
    		    "Precio Neto:  1530\n" +
    		    "IVA:          290\n" +
    		    "Precio Total: 1820\n", Pedido1.generarTextoFactura(), "La factura no se generó correctamente");
    }
    @Test
    void testGuardarFactura() throws IOException {
        Pedido pedido = new Pedido("Camila", "Calle del Toro");

        ProductoMenu p1 = new ProductoMenu("QueenBurger", 1200);
        ProductoMenu p2 = new ProductoMenu("Sprite", 110);
        pedido.agregarProducto(p1);
        pedido.agregarProducto(p2);

   
        File archivoTemporal = File.createTempFile("factura_test", ".txt");
        archivoTemporal.deleteOnExit(); 

        pedido.guardarFactura(archivoTemporal);

        
        List<String> lineas = Files.readAllLines(archivoTemporal.toPath());

        assertTrue(lineas.get(0).contains("Cliente: Camila"));
        assertTrue(lineas.get(1).contains("Dirección: Calle del Toro"));
        assertTrue(lineas.stream().anyMatch(l -> l.contains("QueenBurger")));
        assertTrue(lineas.stream().anyMatch(l -> l.contains("Sprite")));
        assertTrue(lineas.stream().anyMatch(l -> l.contains("Precio Total")));
    }
    @Test
    void testNoHayPedidoEnCursoException() {
        NoHayPedidoEnCursoException nop = new NoHayPedidoEnCursoException();
        assertEquals("Actualmente no hay un pedido en curso", nop.getMessage());
    }
}