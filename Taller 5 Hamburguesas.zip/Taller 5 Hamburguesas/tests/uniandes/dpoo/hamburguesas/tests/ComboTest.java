package uniandes.dpoo.hamburguesas.tests;



import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.excepciones.*;


public class ComboTest {
	private ProductoMenu p1; 
	private ProductoMenu p2;
	private ProductoMenu p3;
    private ArrayList<ProductoMenu> itemsCombo;
    private Combo Combo1;
    @BeforeEach
    void setUp( ) throws Exception
    {
    	p1 = new ProductoMenu("Hamburguesa Doble", 980);
    	p2 = new ProductoMenu("CheesyFries", 1000);
    	p3 = new ProductoMenu("MiCola", 550);
        itemsCombo = new ArrayList<ProductoMenu>();
        itemsCombo.add(p1);
        itemsCombo.add(p2);
        itemsCombo.add(p3);
        Combo1 = new Combo("Especial", 0.2, itemsCombo);
    }
    @AfterEach
    void tearDown( ) throws Exception
    {

    }
    @Test
    void testGetNombre( )
    {
        assertEquals( "Especial", Combo1.getNombre( ), "El nombre del producto no es el esperado." );
    }
    @Test
    void testGetPrecio() 
    {
    	assertEquals (506, Combo1.getPrecio(), "El precio no es correcto!!!");
    }
    @Test
    void testGenerarTextoFactura() {
        String esperado = "Combo Especial\n" +
                          " Descuento: 0.2\n" +
                          "            506\n";
        assertEquals(esperado, Combo1.generarTextoFactura(), "No se ha generado la factura en el formato deseado");
    }
    @Test
    void testProductoFaltanteExceptionMessage() {
        ProductoFaltanteException fal = new ProductoFaltanteException("MiCola");
        assertEquals("El producto MiCola no aparece en la información del restaurante", fal.getMessage());
    }

}
