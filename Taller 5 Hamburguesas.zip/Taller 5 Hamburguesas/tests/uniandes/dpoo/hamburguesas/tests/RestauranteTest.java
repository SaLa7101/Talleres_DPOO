package uniandes.dpoo.hamburguesas.tests;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;


import uniandes.dpoo.hamburguesas.excepciones.*;
import java.util.ArrayList;


import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;


public class RestauranteTest {
    private Restaurante restorant;

    @BeforeEach
    void setUp() {
        restorant = new Restaurante();
    }
    @AfterEach
    void tearDown( ) throws Exception
    {
    	
    }
    
    @Test
    void testIniciarPedido() throws YaHayUnPedidoEnCursoException {
        restorant.iniciarPedido("Mateo", "Calle del león");
        Pedido pedido = restorant.getPedidoEnCurso();
        assertEquals("Mateo", pedido.getNombreCliente(), "La información del Cliente no es correcta");     
    }
    @Test
    void testIniciarPedidoCuandoYaHayUno() throws YaHayUnPedidoEnCursoException {
        restorant.iniciarPedido("Mateo", "Calle del león");

        try {
            restorant.iniciarPedido("Ana", "Calle Garcia");
            fail("Se esperaba YaHayUnPedidoEnCursoException, pero no se lanzó");
        } catch (YaHayUnPedidoEnCursoException e) {
            assertTrue(e.getMessage().contains("Mateo"));
        }
    }
    @Test
    void testGetPedidos() throws Exception {
        restorant.iniciarPedido("Ana", "Calle Garcia");
        restorant.getPedidoEnCurso().agregarProducto(new ProductoMenu("Hamburguesa Sencilla", 15000)); 
        restorant.cerrarYGuardarPedido();

        ArrayList<Pedido> pedidos = restorant.getPedidos();

        assertEquals(1, pedidos.size(), "Debe haber un pedido en la lista");
        assertEquals("Ana", pedidos.get(0).getNombreCliente());
    }

    @Test 
    void testGetMenuBase() throws IOException, NumberFormatException, HamburguesaException 
    {
        File tempIngredientes = File.createTempFile("ingredientes", ".txt");
        File tempCombos = File.createTempFile("combos", ".txt");
        File tempMenu = File.createTempFile("menu", ".txt");
        FileWriter writer = new FileWriter(tempMenu);
        writer.write("Hamburguesa Sencilla;1500\n");
        writer.write("Hamburguesa Doble;1700\n");
        writer.write("Cheese Burger;2000\n");
        writer.close();
        
        restorant.cargarInformacionRestaurante(tempIngredientes, tempMenu, tempCombos);
        ArrayList<ProductoMenu> menuBase = restorant.getMenuBase();
       
        assertEquals(3, menuBase.size(), "El menú debe tener 3 productos");
        assertEquals("Hamburguesa Sencilla", menuBase.get(0).getNombre());
        assertEquals(1500, menuBase.get(0).getPrecio());
        tempIngredientes.delete();
        tempCombos.delete();
        tempMenu.delete();
    }
    @Test 
    void testCargarIngredientes() throws IOException, NumberFormatException, HamburguesaException
    {
    	 File tempIngredientes = File.createTempFile("ingredientes", ".txt");
    	 File tempCombos = File.createTempFile("combos", ".txt");
         File tempMenu = File.createTempFile("menu", ".txt");
    	 FileWriter writer = new FileWriter(tempIngredientes);
         writer.write("Queso;100\n");
         writer.write("Lechuga;70\n");
         writer.write("Pan;20\n");
         writer.close();
         restorant.cargarInformacionRestaurante(tempIngredientes, tempMenu, tempCombos);
         ArrayList<Ingrediente> ingredients = restorant.getIngredientes();
         assertEquals(3, ingredients.size(), "El menú debe tener 3 ingredientes");
         assertEquals("Lechuga", ingredients.get(1).getNombre());
         
    }
    @Test
    void testCargarMenu() throws IOException, NumberFormatException, HamburguesaException 
    {
    	File tempingredientes = File.createTempFile("ingredientes", ".txt");
    	File tempcombos = File.createTempFile("combos", ".txt");		
        File tempMenu = File.createTempFile("menu", ".txt");
        tempMenu.deleteOnExit();  

        FileWriter writer = new FileWriter(tempMenu);
        writer.write("Hamburguesa sencilla;1000\n");
        writer.write("Papas medianas;300\n");
        writer.write("Gaseosa;100\n");
        writer.close();
        Restaurante restaurante = new Restaurante();
        restaurante.cargarInformacionRestaurante(
            tempingredientes, 
            tempMenu,
            tempcombos
        );
        assertEquals(3, restaurante.getMenuBase().size(), "El menú debe contener 3 productos");
        assertEquals("Hamburguesa sencilla", restaurante.getMenuBase().get(0).getNombre());
        assertEquals(1000, restaurante.getMenuBase().get(0).getPrecio());
    }
    @Test
    void testCargarCombos() throws IOException, NumberFormatException, HamburguesaException {
        File tempIngredientes = File.createTempFile("ingredientes", ".txt");
        File tempCombos = File.createTempFile("combos", ".txt");
        File tempMenu = File.createTempFile("menu", ".txt");
        FileWriter menuWriter = new FileWriter(tempMenu);
        menuWriter.write("Hamburguesa Sencilla;1500\n");
        menuWriter.write("Papas medianas;500\n");
        menuWriter.write("Gaseosa;300\n");
        menuWriter.close();
        
        FileWriter combosWriter = new FileWriter(tempCombos);
        combosWriter.write("Combo Especial;10%;Hamburguesa Sencilla;Papas medianas;Gaseosa\n");
        combosWriter.write("Combo Especial Queso;10%;Hamburguesa Sencilla;Papas medianas\n");
        combosWriter.close();
        restorant.cargarInformacionRestaurante(tempIngredientes, tempMenu, tempCombos);
        ArrayList<Combo> combos = restorant.getMenuCombos();
        assertEquals(2, combos.size(), "Deben haberse cargado 2 combos");
        Combo combo1 = combos.get(0);
        assertEquals("Combo Especial", combo1.getNombre());
        assertEquals(230, combo1.getPrecio(), "El precio del combo no es correcto");
        
        Combo combo2 = combos.get(1);
        assertEquals("Combo Especial Queso", combo2.getNombre());
        tempIngredientes.delete();
        tempCombos.delete();
        tempMenu.delete();
    }
}